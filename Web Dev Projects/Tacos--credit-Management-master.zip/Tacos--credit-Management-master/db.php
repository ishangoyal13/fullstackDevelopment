<?php


$host = "localhost";
$user = "root";
$pass = "";

$db_name = "credit_management";




# connect to database
$con = new mysqli( $host, $user, $pass, $db_name );

?>
